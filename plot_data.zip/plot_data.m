%Funciton plots both line of best fit and data points in one graph

function plot_data(x,y,poly_order)

%Accounts for small data values
xnew=linspace(min(x),max(x),200);
fitpoints=polyval(poly_order, xnew);

%Plots data and line
plot(x,y, 'r*',xnew,fitpoints)


