%11 Feb 2020
%Elizabeth Gilman
clear 
clc

%Call Function to Ask User for File Name
[file]=filename

%Call Function to get data
[x,y]=data(file)

%Call function to get order
[poly_order]=order(x,y)

%Call function to plot
plot_data(x,y,poly_order)