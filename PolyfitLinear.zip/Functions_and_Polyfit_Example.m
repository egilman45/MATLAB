%Elizabeth Gilamn, Feb 18 2020, Team 24
clear 
clc

loop=1;

while loop==1
    %Get file name and load data
    filename=input('Which file? ','s');
    data=load(filename);

    %Call Function to ask for number
    user_num=get_num;

    %Count how many times the number appears in the data and display
    [r,c]=size(data);

    count=0;

    for i=1:r
        for j=1:c
            if data(i,j)==user_num
                count=count+1;
            end
        end
    end

    disp(['The number ', num2str(user_num), ' appeared ', num2str(count), ' times in the data.'])

    %Get x and y from the data
    x=data(1,:);
    y=data(2,:);

    %Find coefficents for linear relationship
    Coeffs=polyfit(x,y,1);

    %Plug in a value of x into the equation to get resulting y
    %Use user provided number
    yPolyval=polyval(Coeffs,user_num)

    %Plot the points and line of best fit
    yfitpoints=polyval(Coeffs,x);

    plot(x,y,'r*',x,yfitpoints)

    %Ask user if they would like to run the program again
    loop=menu('Would you like to run the program again?','Yes','No')
end
