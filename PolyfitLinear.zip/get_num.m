%Function to Get Number from User

function num=get_num

num=input('Enter a Number: ');
