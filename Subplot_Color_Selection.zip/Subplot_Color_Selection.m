%Elizabeth Gilman, Alex Blake, Zoe Abel 
%Team 24 Classwork 1
clear 
clc

%Allow the user to enter the name of a file
file = input('Enter the name of a file: ','s')
data=load(file);
[rows,cols]=size(data);

%Assign Variables X and Y
if rows==2
    x_var=data(1,:);
    y_var=data(2,:);
elseif cols==2
    x_var=data(:,1);
    y_var=data(:,2);
else 
    disp('Improper Data file formatting')
end

%Allow user to pick one of colors
datacolor = menu('Pick a color', 'Red', 'Blue', 'Green', 'Cyan', 'Magenta')
switch datacolor
    case 1
        color = 'r';
    case 2
        color = 'b';
    case 3
        color = 'g';
    case 4
        color = 'c';
    case 5
        color = 'm';        
end

%Using subplot
star = subplot(x_var, y_var, str(color))

